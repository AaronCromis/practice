var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //
var yyyy = today.getFullYear();

today = mm + '/' + dd + '/' + yyyy;
document.write(today);


function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
 function EventHandler() {
            alert("Hi");
         }
		 
		function cat(){
        document.getElementById('loadingImage').style.visibility="visible";
    }
	
	function hello() {
  var str = "Hear Someone say hello";
  var result = str.link("https://www.youtube.com/watch?v=G4w2ji8xIqk");
  document.getElementById("demo").innerHTML = result;
}


 function change(color){
        document.getElementById("heading").style.background = color;
    }
              
      function play() {
        var audio = document.getElementById("audio");
        audio.play();
      }
	  